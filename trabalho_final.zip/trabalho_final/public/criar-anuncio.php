<?php
// Inclui nosso arquivo de funções de sessão
require_once __DIR__ . '/../app/core/session.php';

// Inicia a sessão de forma segura
startSecureSession();

// Exige que o usuário esteja logado para ver esta página
requireLogin();
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AutoFácil - Criar Anúncio</title>
  <link rel="icon" type="image/svg+xml" href="./images/icon.svg" />
  <link rel="stylesheet" href="./css/header-footer.css">
  <link rel="stylesheet" href="./css/criar-anuncio.css">
</head>

<body>

  <header>
    <div class="container">
      <a href="index.html" class="logo">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
          <path
            d="M18.9 12.19C18.78 11.5 18.25 11 17.5 11H6.5C5.75 11 5.22 11.5 5.1 12.19L3 18V21H4.5C4.78 21 5 20.78 5 20.5V20H19V20.5C19 20.78 19.22 21 19.5 21H21V18L18.9 12.19M6.5 13H17.5L18.33 15.5H5.67L6.5 13M8.5 17C9.33 17 10 16.33 10 15.5C10 14.67 9.33 14 8.5 14C7.67 14 7 14.67 7 15.5C7 16.33 7.67 17 8.5 17M15.5 17C16.33 17 17 16.33 17 15.5C17 14.67 16.33 14 15.5 14C14.67 14 14 14.67 14 15.5C14 16.33 14.67 17 15.5 17M5 10H19V8C19 7.45 18.55 7 18 7H6C5.45 7 5 7.45 5 8V10Z">
          </path>
        </svg>
        <span class="logo-text">AutoFácil</span>
      </a>
    </div>
  </header>

  <nav>
    <div class="container">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="login.php">Central do Usuário</a></li>
        <li><a href="cadastro.html">Cadastre-se</a></li>
      </ul>
    </div>
  </nav>

  <main>
    <h1>Criar Novo Anúncio</h1>

    <form id="form-anuncio" action="index.php?url=anuncio/criar" method="post" enctype="multipart/form-data" novalidate>

      <div id="form-message" class="message"></div>

      <div>
        <label for="marca">Marca do Veículo:</label>
        <input type="text" id="marca" name="marca" required>
      </div>

      <div>
        <label for="modelo">Modelo:</label>
        <input type="text" id="modelo" name="modelo" required>
      </div>

      <div>
        <label for="ano">Ano de Fabricação:</label>
        <input type="number" id="ano" name="ano" min="1900" max="2025" required>
      </div>

      <div>
        <label for="cor">Cor:</label>
        <input type="text" id="cor" name="cor" required>
      </div>

      <div>
        <label for="km">Quilometragem:</label>
        <input type="number" id="km" name="km" min="0" required>
      </div>

      <div>
        <label for="valor">Valor (R$):</label>
        <input type="number" id="valor" name="valor" min="0" step="0.01" required>
      </div>

      <div>
        <label for="estado">Estado:</label>
        <select id="estado" name="estado" required>
          <option value="" disabled selected>Selecione um estado</option>
          <option value="AC">Acre</option>
          <option value="AL">Alagoas</option>
          <option value="AP">Amapá</option>
          <option value="AM">Amazonas</option>
          <option value="BA">Bahia</option>
          <option value="CE">Ceará</option>
          <option value="DF">Distrito Federal</option>
          <option value="ES">Espírito Santo</option>
          <option value="GO">Goiás</option>
          <option value="MA">Maranhão</option>
          <option value="MT">Mato Grosso</option>
          <option value="MS">Mato Grosso do Sul</option>
          <option value="MG">Minas Gerais</option>
          <option value="PA">Pará</option>
          <option value="PB">Paraíba</option>
          <option value="PR">Paraná</option>
          <option value="PE">Pernambuco</option>
          <option value="PI">Piauí</option>
          <option value="RJ">Rio de Janeiro</option>
          <option value="RN">Rio Grande do Norte</option>
          <option value="RS">Rio Grande do Sul</option>
          <option value="RO">Rondônia</option>
          <option value="RR">Roraima</option>
          <option value="SC">Santa Catarina</option>
          <option value="SP">São Paulo</option>
          <option value="SE">Sergipe</option>
          <option value="TO">Tocantins</option>
        </select>
      </div>

      <div>
        <label for="cidade">Cidade:</label>
        <input type="text" id="cidade" name="cidade" required>
      </div>

      <div>
        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao" rows="6" required></textarea>
      </div>

      <div>
        <p>Fotos do Veículo (pelo menos três):</p>

        <label for="foto1">Foto 1:</label>
        <input type="file" id="foto1" name="foto1" accept="image/*" required>

        <label for="foto2">Foto 2:</label>
        <input type="file" id="foto2" name="foto2" accept="image/*" required>

        <label for="foto3">Foto 3:</label>
        <input type="file" id="foto3" name="foto3" accept="image/*" required>
      </div>

      <div>
        <button type="submit">Criar Anúncio</button>
      </div>

    </form>
  </main>

  <footer>
    <div>
      <p>&copy; 2025 AutoFácil. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="./js/criar-anuncio.js"></script>
</body>

</html>